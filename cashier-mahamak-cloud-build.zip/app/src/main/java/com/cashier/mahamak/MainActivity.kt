package com.cashier.mahamak

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject

data class Product(val barcode:String,val name:String,val price:Double,var stock:Int)
data class CartItem(val barcode:String,val name:String,val price:Double,var qty:Int)

class Store(private val c:Context) {
    private val p=c.getSharedPreferences("store",Context.MODE_PRIVATE)
    fun pin()=p.getString("pin","1234")!!
    fun setPin(v:String){p.edit().putString("pin",v).apply()}
    fun products():MutableList<Product>{
        val a=JSONArray(p.getString("products","[]"))
        val out=mutableListOf<Product>()
        for(i in 0 until a.length()){val o=a.getJSONObject(i);out+=Product(o.getString("barcode"),o.getString("name"),o.getDouble("price"),o.getInt("stock"))}
        return out
    }
    fun saveProducts(list:List<Product>){
        val a=JSONArray();list.forEach{a.put(JSONObject().apply{put("barcode",it.barcode);put("name",it.name);put("price",it.price);put("stock",it.stock)})}
        p.edit().putString("products",a.toString()).apply()
    }
    fun sales()=p.getInt("sales",0)
    fun addSale(total:Double){p.edit().putInt("sales",sales()+1).putFloat("lastTotal",total.toFloat()).apply()}
}

class MainActivity:ComponentActivity(){
    override fun onCreate(b:Bundle?){super.onCreate(b);setContent{App()}}
    fun printReceipt(items:List<CartItem>,total:Double){
        val w=WebView(this); w.settings.javaScriptEnabled=false
        w.loadDataWithBaseURL(null,"<html dir='rtl'><body><h2>كاشير الراوي</h2>"+items.joinToString("<br>"){ "${it.name} × ${it.qty} = ${it.price*it.qty} ج" }+"<hr><b>الإجمالي: $total ج</b></body></html>","text/html","UTF-8",null)
        w.webViewClient=object:WebViewClient(){override fun onPageFinished(v:WebView?,u:String?){
            val pm=getSystemService(PRINT_SERVICE) as PrintManager
            pm.print("فاتورة كاشير الراوي",v!!.createPrintDocumentAdapter("فاتورة"),PrintAttributes.Builder().build())
        }}
    }
}

@Composable fun App(){
    val ctx=LocalContext.current
    val store=remember{Store(ctx)}
    var ok by remember{mutableStateOf(false)}
    if(!ok) Login(store){ok=true}else Home(store)
}

@Composable fun Login(store:Store,done:()->Unit){
    var pin by remember{mutableStateOf("")}
    var error by remember{mutableStateOf(false)}
    Column(Modifier.fillMaxSize().padding(28.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){
        Text("كاشير الراوي",style=MaterialTheme.typography.headlineLarge)
        Text("إدارة المبيعات والمخزون بدون إنترنت")
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(pin,{if(it.length<=12)pin=it},label={Text("الرقم السري")},visualTransformation=PasswordVisualTransformation(),singleLine=true)
        Spacer(Modifier.height(12.dp))
        Button({if(pin==store.pin())done()else error=true},Modifier.fillMaxWidth()){Text("دخول")}
        if(error) Text("الرقم السري غير صحيح",color=MaterialTheme.colorScheme.error)
    }
}

@Composable fun Home(store:Store){
    var tab by remember{mutableIntStateOf(0)}
    var products by remember{mutableStateOf(store.products())}
    var cart by remember{mutableStateOf(listOf<CartItem>())}
    Scaffold(bottomBar={NavigationBar{
        listOf("البيع","المنتجات","المبيعات").forEachIndexed{i,s->NavigationBarItem(tab==i,{tab=i},label={Text(s)},icon={})}
    }}){pad->Column(Modifier.padding(pad).padding(14.dp).fillMaxSize()){
        Text("كاشير الراوي",style=MaterialTheme.typography.headlineSmall)
        when(tab){
            0->Sale(products,cart,{cart=it},{products=it;store.saveProducts(it)},store)
            1->Products(products,{products=it;store.saveProducts(it)})
            2->Sales(store)
        }
    }}
}

@Composable fun Sale(ps:List<Product>,cart:List<CartItem>,setCart:(List<CartItem>)->Unit,setPs:(List<Product>)->Unit,store:Store){
    val activity=LocalContext.current as Activity
    var code by remember{mutableStateOf("")}
    val total=cart.sumOf{it.price*it.qty}
    Column{
        OutlinedTextField(code,{code=it},label={Text("الباركود")},modifier=Modifier.fillMaxWidth(),singleLine=true)
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
            Button({val p=ps.firstOrNull{it.barcode==code};if(p!=null){val old=cart.firstOrNull{it.barcode==p.barcode};setCart(if(old==null)cart+CartItem(p.barcode,p.name,p.price,1) else cart.map{if(it.barcode==p.barcode)it.copy(qty=it.qty+1)else it})};code=""},Modifier.weight(1f)){Text("إضافة")}
            OutlinedButton({/* camera scanner integration point */},Modifier.weight(1f)){Text("مسح بالكاميرا")}
        }
        LazyColumn(Modifier.weight(1f)){items(cart){x->ListItem({Text(x.name)},supportingContent={Text("${x.qty} × ${x.price} ج")})}}
        Text("الإجمالي: %.2f ج".format(total),style=MaterialTheme.typography.titleLarge)
        Button({if(cart.isNotEmpty()){ps.forEach{p->cart.filter{it.barcode==p.barcode}.forEach{p.stock-=it.qty}};setPs(ps);store.addSale(total);(activity as? MainActivity)?.printReceipt(cart,total);setCart(emptyList())}},Modifier.fillMaxWidth()){Text("إتمام البيع وطباعة الفاتورة")}
    }
}

@Composable fun Products(ps:List<Product>,set:(List<Product>)->Unit){
    var show by remember{mutableStateOf(false)}
    var name by remember{mutableStateOf("")};var code by remember{mutableStateOf("")};var price by remember{mutableStateOf("")};var stock by remember{mutableStateOf("")}
    Button({show=true}){Text("إضافة منتج")}
    LazyColumn{items(ps){p->ListItem({Text(p.name)},supportingContent={Text("${p.barcode} • ${p.price} ج • مخزون ${p.stock}")})}}
    if(show)AlertDialog(onDismissRequest={show=false},confirmButton={Button({val q=Product(code,name,price.toDoubleOrNull()?:0.0,stock.toIntOrNull()?:0);set(ps+q);show=false}){Text("حفظ")}},dismissButton={TextButton({show=false}){Text("إلغاء")}},title={Text("منتج جديد")},text={Column{OutlinedTextField(name,{name=it},label={Text("الاسم")});OutlinedTextField(code,{code=it},label={Text("الباركود")});OutlinedTextField(price,{price=it},label={Text("السعر")});OutlinedTextField(stock,{stock=it},label={Text("المخزون")})}})
}

@Composable fun Sales(store:Store){Column{Text("سجل المبيعات",style=MaterialTheme.typography.titleLarge);Spacer(Modifier.height(10.dp));Text("عدد الفواتير: ${store.sales()}")}}
